﻿namespace WindowsFormsJobBC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            homepanelTop = new Panel();
            homelabelversion = new Label();
            homelabelsubtitle = new Label();
            homelabelnamebusinessfull = new Label();
            homelabelnamebusiness = new Label();
            homelogocalculator = new PictureBox();
            homelogobee = new PictureBox();
            homebutaominimizar = new Button();
            homebutaofechar = new Button();
            homepanelleftsize = new Panel();
            exitbuttonhome = new Button();
            termoeusobuttonhome = new Button();
            PPbuttonhome = new Button();
            metafinanceirabuttonhome = new Button();
            categoriabuttonhome = new Button();
            transacaobuttonhome = new Button();
            contabuttonhome = new Button();
            usuariobuttonhome = new Button();
            bannerhome = new Panel();
            panelpageonehome = new Panel();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            homepanelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).BeginInit();
            ((System.ComponentModel.ISupportInitialize)homelogobee).BeginInit();
            homepanelleftsize.SuspendLayout();
            panelpageonehome.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // homepanelTop
            // 
            homepanelTop.BackColor = Color.Black;
            homepanelTop.Controls.Add(homelabelversion);
            homepanelTop.Controls.Add(homelabelsubtitle);
            homepanelTop.Controls.Add(homelabelnamebusinessfull);
            homepanelTop.Controls.Add(homelabelnamebusiness);
            homepanelTop.Controls.Add(homelogocalculator);
            homepanelTop.Controls.Add(homelogobee);
            homepanelTop.Controls.Add(homebutaominimizar);
            homepanelTop.Controls.Add(homebutaofechar);
            homepanelTop.Dock = DockStyle.Top;
            homepanelTop.Location = new Point(0, 0);
            homepanelTop.Name = "homepanelTop";
            homepanelTop.Size = new Size(1400, 137);
            homepanelTop.TabIndex = 0;
            // 
            // homelabelversion
            // 
            homelabelversion.AutoSize = true;
            homelabelversion.Font = new Font("BankGothic Md BT", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            homelabelversion.ForeColor = Color.Yellow;
            homelabelversion.Location = new Point(319, 98);
            homelabelversion.Name = "homelabelversion";
            homelabelversion.Size = new Size(143, 22);
            homelabelversion.TabIndex = 8;
            homelabelversion.Text = "1.0.01 ver.";
            // 
            // homelabelsubtitle
            // 
            homelabelsubtitle.AutoSize = true;
            homelabelsubtitle.Font = new Font("BankGothic Md BT", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            homelabelsubtitle.ForeColor = Color.Yellow;
            homelabelsubtitle.Location = new Point(323, 65);
            homelabelsubtitle.Name = "homelabelsubtitle";
            homelabelsubtitle.Size = new Size(567, 22);
            homelabelsubtitle.TabIndex = 7;
            homelabelsubtitle.Text = "A system for your personal financial account";
            // 
            // homelabelnamebusinessfull
            // 
            homelabelnamebusinessfull.AutoSize = true;
            homelabelnamebusinessfull.Font = new Font("BankGothic Md BT", 32.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            homelabelnamebusinessfull.ForeColor = Color.Yellow;
            homelabelnamebusinessfull.Location = new Point(315, 6);
            homelabelnamebusinessfull.Name = "homelabelnamebusinessfull";
            homelabelnamebusinessfull.Size = new Size(831, 45);
            homelabelnamebusinessfull.TabIndex = 6;
            homelabelnamebusinessfull.Text = "Personal Countabeelity System";
            homelabelnamebusinessfull.Click += homelabelnamebusinessfull_Click;
            // 
            // homelabelnamebusiness
            // 
            homelabelnamebusiness.AutoSize = true;
            homelabelnamebusiness.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            homelabelnamebusiness.ForeColor = Color.Yellow;
            homelabelnamebusiness.Location = new Point(25, 98);
            homelabelnamebusiness.Name = "homelabelnamebusiness";
            homelabelnamebusiness.Size = new Size(120, 25);
            homelabelnamebusiness.TabIndex = 5;
            homelabelnamebusiness.Text = "PCbeeS";
            homelabelnamebusiness.Click += homelabelnamebusiness_Click;
            // 
            // homelogocalculator
            // 
            homelogocalculator.Image = (Image)resources.GetObject("homelogocalculator.Image");
            homelogocalculator.Location = new Point(84, 28);
            homelogocalculator.Name = "homelogocalculator";
            homelogocalculator.Size = new Size(61, 59);
            homelogocalculator.SizeMode = PictureBoxSizeMode.Zoom;
            homelogocalculator.TabIndex = 4;
            homelogocalculator.TabStop = false;
            // 
            // homelogobee
            // 
            homelogobee.Image = (Image)resources.GetObject("homelogobee.Image");
            homelogobee.Location = new Point(25, 12);
            homelogobee.Name = "homelogobee";
            homelogobee.Size = new Size(62, 75);
            homelogobee.SizeMode = PictureBoxSizeMode.Zoom;
            homelogobee.TabIndex = 3;
            homelogobee.TabStop = false;
            // 
            // homebutaominimizar
            // 
            homebutaominimizar.FlatAppearance.BorderColor = Color.Black;
            homebutaominimizar.FlatAppearance.BorderSize = 0;
            homebutaominimizar.FlatAppearance.MouseDownBackColor = Color.Black;
            homebutaominimizar.FlatAppearance.MouseOverBackColor = Color.Red;
            homebutaominimizar.FlatStyle = FlatStyle.Flat;
            homebutaominimizar.Image = (Image)resources.GetObject("homebutaominimizar.Image");
            homebutaominimizar.Location = new Point(1360, 0);
            homebutaominimizar.Name = "homebutaominimizar";
            homebutaominimizar.RightToLeft = RightToLeft.No;
            homebutaominimizar.Size = new Size(40, 40);
            homebutaominimizar.TabIndex = 2;
            homebutaominimizar.UseVisualStyleBackColor = true;
            homebutaominimizar.Click += homebutaominimizar_Click;
            // 
            // homebutaofechar
            // 
            homebutaofechar.FlatAppearance.BorderColor = Color.Black;
            homebutaofechar.FlatAppearance.BorderSize = 0;
            homebutaofechar.FlatAppearance.MouseDownBackColor = Color.Black;
            homebutaofechar.FlatAppearance.MouseOverBackColor = Color.Red;
            homebutaofechar.FlatStyle = FlatStyle.Flat;
            homebutaofechar.Image = (Image)resources.GetObject("homebutaofechar.Image");
            homebutaofechar.ImageAlign = ContentAlignment.TopRight;
            homebutaofechar.Location = new Point(1400, 0);
            homebutaofechar.Name = "homebutaofechar";
            homebutaofechar.RightToLeft = RightToLeft.No;
            homebutaofechar.Size = new Size(40, 40);
            homebutaofechar.TabIndex = 0;
            homebutaofechar.UseVisualStyleBackColor = true;
            homebutaofechar.Click += homebutaofechar_Click;
            // 
            // homepanelleftsize
            // 
            homepanelleftsize.BackColor = Color.FromArgb(33, 33, 33);
            homepanelleftsize.Controls.Add(exitbuttonhome);
            homepanelleftsize.Controls.Add(termoeusobuttonhome);
            homepanelleftsize.Controls.Add(PPbuttonhome);
            homepanelleftsize.Controls.Add(metafinanceirabuttonhome);
            homepanelleftsize.Controls.Add(categoriabuttonhome);
            homepanelleftsize.Controls.Add(transacaobuttonhome);
            homepanelleftsize.Controls.Add(contabuttonhome);
            homepanelleftsize.Controls.Add(usuariobuttonhome);
            homepanelleftsize.Dock = DockStyle.Left;
            homepanelleftsize.Location = new Point(0, 137);
            homepanelleftsize.Name = "homepanelleftsize";
            homepanelleftsize.Size = new Size(328, 763);
            homepanelleftsize.TabIndex = 1;
            // 
            // exitbuttonhome
            // 
            exitbuttonhome.FlatAppearance.BorderColor = Color.Black;
            exitbuttonhome.FlatAppearance.BorderSize = 0;
            exitbuttonhome.FlatAppearance.MouseDownBackColor = Color.Black;
            exitbuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            exitbuttonhome.FlatStyle = FlatStyle.Flat;
            exitbuttonhome.Image = (Image)resources.GetObject("exitbuttonhome.Image");
            exitbuttonhome.Location = new Point(247, 703);
            exitbuttonhome.Name = "exitbuttonhome";
            exitbuttonhome.RightToLeft = RightToLeft.No;
            exitbuttonhome.Size = new Size(55, 48);
            exitbuttonhome.TabIndex = 8;
            exitbuttonhome.UseVisualStyleBackColor = true;
            exitbuttonhome.Click += exitbuttonhome_Click;
            // 
            // termoeusobuttonhome
            // 
            termoeusobuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            termoeusobuttonhome.FlatAppearance.BorderSize = 0;
            termoeusobuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            termoeusobuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            termoeusobuttonhome.FlatStyle = FlatStyle.Flat;
            termoeusobuttonhome.Font = new Font("BankGothic Md BT", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            termoeusobuttonhome.ForeColor = Color.Yellow;
            termoeusobuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            termoeusobuttonhome.Location = new Point(12, 730);
            termoeusobuttonhome.Name = "termoeusobuttonhome";
            termoeusobuttonhome.Size = new Size(174, 21);
            termoeusobuttonhome.TabIndex = 7;
            termoeusobuttonhome.Text = "Termo e Uso";
            termoeusobuttonhome.TextAlign = ContentAlignment.MiddleLeft;
            termoeusobuttonhome.UseVisualStyleBackColor = true;
            termoeusobuttonhome.Click += termoeusobuttonhome_Click;
            // 
            // PPbuttonhome
            // 
            PPbuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            PPbuttonhome.FlatAppearance.BorderSize = 0;
            PPbuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            PPbuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            PPbuttonhome.FlatStyle = FlatStyle.Flat;
            PPbuttonhome.Font = new Font("BankGothic Md BT", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PPbuttonhome.ForeColor = Color.Yellow;
            PPbuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            PPbuttonhome.Location = new Point(12, 703);
            PPbuttonhome.Name = "PPbuttonhome";
            PPbuttonhome.Size = new Size(174, 21);
            PPbuttonhome.TabIndex = 6;
            PPbuttonhome.Text = "Política e Privacidade";
            PPbuttonhome.TextAlign = ContentAlignment.MiddleLeft;
            PPbuttonhome.UseVisualStyleBackColor = true;
            PPbuttonhome.Click += PPbuttonhome_Click;
            // 
            // metafinanceirabuttonhome
            // 
            metafinanceirabuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            metafinanceirabuttonhome.FlatAppearance.BorderSize = 0;
            metafinanceirabuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            metafinanceirabuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            metafinanceirabuttonhome.FlatStyle = FlatStyle.Flat;
            metafinanceirabuttonhome.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            metafinanceirabuttonhome.ForeColor = Color.Yellow;
            metafinanceirabuttonhome.Image = (Image)resources.GetObject("metafinanceirabuttonhome.Image");
            metafinanceirabuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            metafinanceirabuttonhome.Location = new Point(12, 324);
            metafinanceirabuttonhome.Name = "metafinanceirabuttonhome";
            metafinanceirabuttonhome.Size = new Size(290, 44);
            metafinanceirabuttonhome.TabIndex = 4;
            metafinanceirabuttonhome.Text = "MetaFinanceira";
            metafinanceirabuttonhome.TextAlign = ContentAlignment.MiddleRight;
            metafinanceirabuttonhome.UseVisualStyleBackColor = true;
            metafinanceirabuttonhome.Click += metafinanceirabuttonhome_Click;
            // 
            // categoriabuttonhome
            // 
            categoriabuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            categoriabuttonhome.FlatAppearance.BorderSize = 0;
            categoriabuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            categoriabuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            categoriabuttonhome.FlatStyle = FlatStyle.Flat;
            categoriabuttonhome.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            categoriabuttonhome.ForeColor = Color.Yellow;
            categoriabuttonhome.Image = (Image)resources.GetObject("categoriabuttonhome.Image");
            categoriabuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            categoriabuttonhome.Location = new Point(12, 250);
            categoriabuttonhome.Name = "categoriabuttonhome";
            categoriabuttonhome.Size = new Size(290, 44);
            categoriabuttonhome.TabIndex = 3;
            categoriabuttonhome.Text = "Categoria   ";
            categoriabuttonhome.UseVisualStyleBackColor = true;
            categoriabuttonhome.Click += categoriabuttonhome_Click;
            // 
            // transacaobuttonhome
            // 
            transacaobuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            transacaobuttonhome.FlatAppearance.BorderSize = 0;
            transacaobuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            transacaobuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            transacaobuttonhome.FlatStyle = FlatStyle.Flat;
            transacaobuttonhome.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            transacaobuttonhome.ForeColor = Color.Yellow;
            transacaobuttonhome.Image = (Image)resources.GetObject("transacaobuttonhome.Image");
            transacaobuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            transacaobuttonhome.Location = new Point(12, 180);
            transacaobuttonhome.Name = "transacaobuttonhome";
            transacaobuttonhome.Size = new Size(290, 44);
            transacaobuttonhome.TabIndex = 2;
            transacaobuttonhome.Text = "Transação  ";
            transacaobuttonhome.UseVisualStyleBackColor = true;
            transacaobuttonhome.Click += transacaobuttonhome_Click;
            // 
            // contabuttonhome
            // 
            contabuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            contabuttonhome.FlatAppearance.BorderSize = 0;
            contabuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            contabuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            contabuttonhome.FlatStyle = FlatStyle.Flat;
            contabuttonhome.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            contabuttonhome.ForeColor = Color.Yellow;
            contabuttonhome.Image = (Image)resources.GetObject("contabuttonhome.Image");
            contabuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            contabuttonhome.Location = new Point(12, 114);
            contabuttonhome.Name = "contabuttonhome";
            contabuttonhome.Size = new Size(290, 44);
            contabuttonhome.TabIndex = 1;
            contabuttonhome.Text = "Conta         ";
            contabuttonhome.UseVisualStyleBackColor = true;
            contabuttonhome.Click += contabuttonhome_Click;
            // 
            // usuariobuttonhome
            // 
            usuariobuttonhome.FlatAppearance.BorderColor = Color.FromArgb(33, 33, 33);
            usuariobuttonhome.FlatAppearance.BorderSize = 0;
            usuariobuttonhome.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            usuariobuttonhome.FlatAppearance.MouseOverBackColor = Color.Black;
            usuariobuttonhome.FlatStyle = FlatStyle.Flat;
            usuariobuttonhome.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            usuariobuttonhome.ForeColor = Color.Yellow;
            usuariobuttonhome.Image = (Image)resources.GetObject("usuariobuttonhome.Image");
            usuariobuttonhome.ImageAlign = ContentAlignment.MiddleLeft;
            usuariobuttonhome.Location = new Point(12, 43);
            usuariobuttonhome.Name = "usuariobuttonhome";
            usuariobuttonhome.Size = new Size(290, 44);
            usuariobuttonhome.TabIndex = 0;
            usuariobuttonhome.Text = "Usuário      ";
            usuariobuttonhome.UseVisualStyleBackColor = true;
            usuariobuttonhome.Click += usuariobuttonhome_Click;
            // 
            // bannerhome
            // 
            bannerhome.BackColor = Color.Transparent;
            bannerhome.BackgroundImage = (Image)resources.GetObject("bannerhome.BackgroundImage");
            bannerhome.Location = new Point(328, 137);
            bannerhome.Margin = new Padding(0);
            bannerhome.Name = "bannerhome";
            bannerhome.Size = new Size(1210, 300);
            bannerhome.TabIndex = 2;
            // 
            // panelpageonehome
            // 
            panelpageonehome.BackColor = Color.WhiteSmoke;
            panelpageonehome.Controls.Add(label6);
            panelpageonehome.Controls.Add(label5);
            panelpageonehome.Controls.Add(label4);
            panelpageonehome.Controls.Add(label3);
            panelpageonehome.Controls.Add(label2);
            panelpageonehome.Controls.Add(label1);
            panelpageonehome.Location = new Point(328, 437);
            panelpageonehome.Margin = new Padding(0);
            panelpageonehome.Name = "panelpageonehome";
            panelpageonehome.Size = new Size(605, 465);
            panelpageonehome.TabIndex = 3;
            panelpageonehome.Paint += panelpageonehome_Paint;
            // 
            // label6
            // 
            label6.AccessibleRole = AccessibleRole.Text;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(40, 365);
            label6.Name = "label6";
            label6.Size = new Size(455, 42);
            label6.TabIndex = 5;
            label6.Text = "A página usuário servirá para inserir o tipo de transação, o valor,\r\na descrição, a data da transação.";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(34, 327);
            label5.Name = "label5";
            label5.Size = new Size(165, 25);
            label5.TabIndex = 4;
            label5.Text = "Transação";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AccessibleRole = AccessibleRole.Text;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(40, 226);
            label4.Name = "label4";
            label4.Size = new Size(464, 42);
            label4.TabIndex = 3;
            label4.Text = "A página usuário servirá para inserir ou apresentar Tipo de Conta,\r\na instituição, o seu saldo e a data da abertura.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(34, 190);
            label3.Name = "label3";
            label3.Size = new Size(100, 25);
            label3.TabIndex = 2;
            label3.Text = "Conta";
            // 
            // label2
            // 
            label2.AccessibleRole = AccessibleRole.Text;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(40, 97);
            label2.Name = "label2";
            label2.Size = new Size(471, 21);
            label2.TabIndex = 1;
            label2.Text = "A página usuário servirá para inserir ou apresentar Nome e E-mail.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(34, 66);
            label1.Name = "label1";
            label1.Size = new Size(128, 25);
            label1.TabIndex = 0;
            label1.Text = "Usuário";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Location = new Point(936, 437);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(605, 465);
            panel1.TabIndex = 4;
            // 
            // label12
            // 
            label12.AccessibleRole = AccessibleRole.Text;
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(63, 365);
            label12.Name = "label12";
            label12.Size = new Size(414, 42);
            label12.TabIndex = 6;
            label12.Text = "A página usuário servirá para inserir ou apresentar o Valor\r\nlimite e a descrição do Alerta.";
            // 
            // label11
            // 
            label11.AccessibleRole = AccessibleRole.Text;
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(63, 226);
            label11.Name = "label11";
            label11.Size = new Size(401, 42);
            label11.TabIndex = 5;
            label11.Text = "A página usuário servirá para inserir ou apresentar Valor\r\ne descrição da meta e sua data limite.";
            // 
            // label10
            // 
            label10.AccessibleRole = AccessibleRole.Text;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(63, 97);
            label10.Name = "label10";
            label10.Size = new Size(408, 42);
            label10.TabIndex = 4;
            label10.Text = "A página usuário servirá para inserir ou apresentar Nome\r\ne Tipo da categoria.";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(59, 327);
            label9.Name = "label9";
            label9.Size = new Size(111, 25);
            label9.TabIndex = 3;
            label9.Text = "Alerta";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(59, 190);
            label8.Name = "label8";
            label8.Size = new Size(245, 25);
            label8.TabIndex = 2;
            label8.Text = "Meta Financeira";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("BankGothic Md BT", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(59, 66);
            label7.Name = "label7";
            label7.Size = new Size(158, 25);
            label7.TabIndex = 1;
            label7.Text = "Categoria";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1400, 900);
            Controls.Add(panel1);
            Controls.Add(panelpageonehome);
            Controls.Add(bannerhome);
            Controls.Add(homepanelleftsize);
            Controls.Add(homepanelTop);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            WindowState = FormWindowState.Maximized;
            homepanelTop.ResumeLayout(false);
            homepanelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).EndInit();
            ((System.ComponentModel.ISupportInitialize)homelogobee).EndInit();
            homepanelleftsize.ResumeLayout(false);
            panelpageonehome.ResumeLayout(false);
            panelpageonehome.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel homepanelTop;
        private Panel homepanelleftsize;
        private Button homebutaofechar;
        private Button homebutaominimizar;
        private PictureBox homelogocalculator;
        private PictureBox homelogobee;
        private Label homelabelnamebusiness;
        private Label homelabelnamebusinessfull;
        private Label homelabelversion;
        private Label homelabelsubtitle;
        private Button usuariobuttonhome;
        private Button contabuttonhome;
        private Button transacaobuttonhome;
        private Button metafinanceirabuttonhome;
        private Button categoriabuttonhome;
        private Button PPbuttonhome;
        private Button exitbuttonhome;
        private Button termoeusobuttonhome;
        private Panel bannerhome;
        private Panel panelpageonehome;
        private Panel panel1;
        private Label label1;
        private Label label2;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label12;
        private Label label11;
    }
}
