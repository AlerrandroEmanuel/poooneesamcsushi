﻿namespace WindowsFormsJobBC
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            panel1 = new Panel();
            label12 = new Label();
            label2 = new Label();
            label16 = new Label();
            txt_instituicao_conta = new TextBox();
            label11 = new Label();
            txt_email_usuario = new TextBox();
            label10 = new Label();
            txt_data_limite_meta_financeira = new TextBox();
            label9 = new Label();
            txt_valor_meta_financeira = new TextBox();
            label8 = new Label();
            txt_descricao_meta_financeira = new TextBox();
            label7 = new Label();
            txt_saldo_conta = new TextBox();
            label6 = new Label();
            txt_tipo_conta = new TextBox();
            label5 = new Label();
            label3 = new Label();
            exitbtnuser = new Button();
            button1 = new Button();
            txt_nome_usuario = new TextBox();
            homelogocalculator = new PictureBox();
            homelogobee = new PictureBox();
            label1 = new Label();
            homelabelnamebusiness = new Label();
            panel2 = new Panel();
            lv_show_usuario = new ListView();
            Nome = new ColumnHeader();
            Email = new ColumnHeader();
            Tipo_Conta = new ColumnHeader();
            Saldo = new ColumnHeader();
            Instituição = new ColumnHeader();
            Descrição_Meta = new ColumnHeader();
            Data_limite_Meta = new ColumnHeader();
            Valor_Meta = new ColumnHeader();
            label4 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).BeginInit();
            ((System.ComponentModel.ISupportInitialize)homelogobee).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(18, 18, 18);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(txt_instituicao_conta);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(txt_email_usuario);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(txt_data_limite_meta_financeira);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(txt_valor_meta_financeira);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txt_descricao_meta_financeira);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txt_saldo_conta);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txt_tipo_conta);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(exitbtnuser);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(txt_nome_usuario);
            panel1.Controls.Add(homelogocalculator);
            panel1.Controls.Add(homelogobee);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(homelabelnamebusiness);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(600, 800);
            panel1.TabIndex = 0;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Yellow;
            label12.Location = new Point(12, 152);
            label12.Name = "label12";
            label12.RightToLeft = RightToLeft.No;
            label12.Size = new Size(141, 28);
            label12.TabIndex = 40;
            label12.Text = "Usuário";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Yellow;
            label2.Location = new Point(12, 468);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(268, 28);
            label2.TabIndex = 39;
            label2.Text = "Meta Financeira";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Yellow;
            label16.Location = new Point(12, 274);
            label16.Name = "label16";
            label16.RightToLeft = RightToLeft.No;
            label16.Size = new Size(110, 28);
            label16.TabIndex = 38;
            label16.Text = "Conta";
            // 
            // txt_instituicao_conta
            // 
            txt_instituicao_conta.Location = new Point(320, 333);
            txt_instituicao_conta.Name = "txt_instituicao_conta";
            txt_instituicao_conta.Size = new Size(250, 23);
            txt_instituicao_conta.TabIndex = 29;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Yellow;
            label11.Location = new Point(316, 311);
            label11.Name = "label11";
            label11.Size = new Size(123, 17);
            label11.TabIndex = 28;
            label11.Text = "Instituição:";
            // 
            // txt_email_usuario
            // 
            txt_email_usuario.Location = new Point(323, 211);
            txt_email_usuario.Name = "txt_email_usuario";
            txt_email_usuario.Size = new Size(250, 23);
            txt_email_usuario.TabIndex = 27;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Yellow;
            label10.Location = new Point(319, 189);
            label10.Name = "label10";
            label10.RightToLeft = RightToLeft.No;
            label10.Size = new Size(67, 17);
            label10.TabIndex = 26;
            label10.Text = "Email:";
            // 
            // txt_data_limite_meta_financeira
            // 
            txt_data_limite_meta_financeira.Location = new Point(19, 599);
            txt_data_limite_meta_financeira.Name = "txt_data_limite_meta_financeira";
            txt_data_limite_meta_financeira.Size = new Size(250, 23);
            txt_data_limite_meta_financeira.TabIndex = 25;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Yellow;
            label9.Location = new Point(16, 579);
            label9.Name = "label9";
            label9.Size = new Size(181, 17);
            label9.TabIndex = 24;
            label9.Text = "Data Limite Meta:";
            // 
            // txt_valor_meta_financeira
            // 
            txt_valor_meta_financeira.Location = new Point(319, 532);
            txt_valor_meta_financeira.Name = "txt_valor_meta_financeira";
            txt_valor_meta_financeira.Size = new Size(250, 23);
            txt_valor_meta_financeira.TabIndex = 23;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Yellow;
            label8.Location = new Point(316, 512);
            label8.Name = "label8";
            label8.Size = new Size(125, 17);
            label8.TabIndex = 22;
            label8.Text = "Valor Meta:";
            // 
            // txt_descricao_meta_financeira
            // 
            txt_descricao_meta_financeira.Location = new Point(19, 534);
            txt_descricao_meta_financeira.Name = "txt_descricao_meta_financeira";
            txt_descricao_meta_financeira.Size = new Size(250, 23);
            txt_descricao_meta_financeira.TabIndex = 21;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Yellow;
            label7.Location = new Point(16, 512);
            label7.Name = "label7";
            label7.Size = new Size(169, 17);
            label7.TabIndex = 20;
            label7.Text = "Descrição Meta:";
            // 
            // txt_saldo_conta
            // 
            txt_saldo_conta.Location = new Point(19, 393);
            txt_saldo_conta.Name = "txt_saldo_conta";
            txt_saldo_conta.Size = new Size(250, 23);
            txt_saldo_conta.TabIndex = 19;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Yellow;
            label6.Location = new Point(16, 373);
            label6.Name = "label6";
            label6.Size = new Size(73, 17);
            label6.TabIndex = 18;
            label6.Text = "Saldo:";
            // 
            // txt_tipo_conta
            // 
            txt_tipo_conta.Location = new Point(19, 333);
            txt_tipo_conta.Name = "txt_tipo_conta";
            txt_tipo_conta.Size = new Size(250, 23);
            txt_tipo_conta.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Yellow;
            label5.Location = new Point(16, 311);
            label5.Name = "label5";
            label5.Size = new Size(54, 17);
            label5.TabIndex = 16;
            label5.Text = "Tipo:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Yellow;
            label3.Location = new Point(166, 48);
            label3.Name = "label3";
            label3.Size = new Size(141, 28);
            label3.TabIndex = 15;
            label3.Text = "Usuário";
            // 
            // exitbtnuser
            // 
            exitbtnuser.FlatAppearance.BorderColor = Color.Black;
            exitbtnuser.FlatAppearance.BorderSize = 0;
            exitbtnuser.FlatAppearance.MouseDownBackColor = Color.Black;
            exitbtnuser.FlatAppearance.MouseOverBackColor = Color.Black;
            exitbtnuser.FlatStyle = FlatStyle.Flat;
            exitbtnuser.Image = (Image)resources.GetObject("exitbtnuser.Image");
            exitbtnuser.Location = new Point(525, 740);
            exitbtnuser.Name = "exitbtnuser";
            exitbtnuser.RightToLeft = RightToLeft.No;
            exitbtnuser.Size = new Size(45, 48);
            exitbtnuser.TabIndex = 14;
            exitbtnuser.UseVisualStyleBackColor = true;
            exitbtnuser.Click += exitbtnuser_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.FlatAppearance.BorderColor = Color.Yellow;
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 33, 33);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Yellow;
            button1.Location = new Point(19, 748);
            button1.Margin = new Padding(0);
            button1.Name = "button1";
            button1.Size = new Size(89, 33);
            button1.TabIndex = 13;
            button1.Text = "Enviar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txt_nome_usuario
            // 
            txt_nome_usuario.Location = new Point(22, 211);
            txt_nome_usuario.Name = "txt_nome_usuario";
            txt_nome_usuario.Size = new Size(250, 23);
            txt_nome_usuario.TabIndex = 11;
            txt_nome_usuario.TextChanged += txt_nome_TextChanged;
            // 
            // homelogocalculator
            // 
            homelogocalculator.Image = (Image)resources.GetObject("homelogocalculator.Image");
            homelogocalculator.Location = new Point(80, 33);
            homelogocalculator.Name = "homelogocalculator";
            homelogocalculator.Size = new Size(61, 59);
            homelogocalculator.SizeMode = PictureBoxSizeMode.Zoom;
            homelogocalculator.TabIndex = 10;
            homelogocalculator.TabStop = false;
            // 
            // homelogobee
            // 
            homelogobee.Image = (Image)resources.GetObject("homelogobee.Image");
            homelogobee.Location = new Point(12, 17);
            homelogobee.Name = "homelogobee";
            homelogobee.Size = new Size(62, 75);
            homelogobee.SizeMode = PictureBoxSizeMode.Zoom;
            homelogobee.TabIndex = 9;
            homelogobee.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.Location = new Point(19, 189);
            label1.Name = "label1";
            label1.Size = new Size(65, 17);
            label1.TabIndex = 7;
            label1.Text = "Nome:";
            // 
            // homelabelnamebusiness
            // 
            homelabelnamebusiness.AutoSize = true;
            homelabelnamebusiness.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            homelabelnamebusiness.ForeColor = Color.Yellow;
            homelabelnamebusiness.Location = new Point(12, 95);
            homelabelnamebusiness.Name = "homelabelnamebusiness";
            homelabelnamebusiness.Size = new Size(132, 28);
            homelabelnamebusiness.TabIndex = 6;
            homelabelnamebusiness.Text = "PCbeeS";
            homelabelnamebusiness.Click += homelabelnamebusiness_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightGray;
            panel2.Controls.Add(lv_show_usuario);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(600, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(600, 800);
            panel2.TabIndex = 1;
            // 
            // lv_show_usuario
            // 
            lv_show_usuario.Columns.AddRange(new ColumnHeader[] { Nome, Email, Tipo_Conta, Saldo, Instituição, Descrição_Meta, Data_limite_Meta, Valor_Meta });
            lv_show_usuario.Location = new Point(31, 95);
            lv_show_usuario.Name = "lv_show_usuario";
            lv_show_usuario.Size = new Size(541, 686);
            lv_show_usuario.TabIndex = 17;
            lv_show_usuario.UseCompatibleStateImageBehavior = false;
            lv_show_usuario.View = View.Details;
            lv_show_usuario.SelectedIndexChanged += lv_show_usuario_SelectedIndexChanged;
            // 
            // Nome
            // 
            Nome.Text = "Nome";
            Nome.Width = 120;
            // 
            // Email
            // 
            Email.Text = "Email";
            Email.Width = 120;
            // 
            // Tipo_Conta
            // 
            Tipo_Conta.Text = "Tipo_Conta";
            Tipo_Conta.Width = 120;
            // 
            // Saldo
            // 
            Saldo.Text = "Saldo";
            // 
            // Instituição
            // 
            Instituição.Text = "Instituição";
            Instituição.Width = 120;
            // 
            // Descrição_Meta
            // 
            Descrição_Meta.Text = "Descrição_Meta";
            Descrição_Meta.Width = 200;
            // 
            // Data_limite_Meta
            // 
            Data_limite_Meta.Text = "Data_limite_Meta";
            Data_limite_Meta.Width = 120;
            // 
            // Valor_Meta
            // 
            Valor_Meta.Text = "Valor_Meta";
            Valor_Meta.Width = 120;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(31, 48);
            label4.Name = "label4";
            label4.Size = new Size(212, 28);
            label4.TabIndex = 16;
            label4.Text = "Informações";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 800);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).EndInit();
            ((System.ComponentModel.ISupportInitialize)homelogobee).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label homelabelnamebusiness;
        private Label label1;
        private PictureBox homelogobee;
        private TextBox txt_nome_usuario;
        private PictureBox homelogocalculator;
        private TextBox txt_email;
        private Button button1;
        private Button exitbtnuser;
        private Label label3;
        private Label label4;
        private ListView lv_show_usuario;
        private TextBox txt_descricao_meta_financeira;
        private Label label7;
        private TextBox txt_saldo_conta;
        private Label label6;
        private TextBox txt_tipo_conta;
        private Label label5;
        private TextBox txt_instituicao_conta;
        private Label label11;
        private TextBox txt_email_usuario;
        private Label label10;
        private TextBox txt_data_limite_meta_financeira;
        private Label label9;
        private TextBox txt_valor_meta_financeira;
        private Label label8;
        private Label label16;
        private Label label2;
        private Label label12;
        private ColumnHeader Nome;
        private ColumnHeader Email;
        private ColumnHeader Tipo_Conta;
        private ColumnHeader Saldo;
        private ColumnHeader Instituição;
        private ColumnHeader Descrição_Meta;
        private ColumnHeader Data_limite_Meta;
        private ColumnHeader Valor_Meta;
    }
}