﻿namespace WindowsFormsJobBC
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            homelabelnamebusiness = new Label();
            label1 = new Label();
            homelogobee = new PictureBox();
            homelogocalculator = new PictureBox();
            txt_tipo_transacao = new TextBox();
            btn_enviartransacao = new Button();
            exitbtn_transacao = new Button();
            label3 = new Label();
            label10 = new Label();
            txt_valor_transacao = new TextBox();
            label12 = new Label();
            panel1 = new Panel();
            label6 = new Label();
            txt_nome_usuario = new TextBox();
            label11 = new Label();
            label7 = new Label();
            txt_tipo_categoria = new TextBox();
            label8 = new Label();
            txt_nome_categoria = new TextBox();
            label9 = new Label();
            txt_data_transacao = new TextBox();
            label2 = new Label();
            txt_descricao_transacao = new TextBox();
            label4 = new Label();
            lv_show_transacao = new ListView();
            Tipo_Transação = new ColumnHeader();
            Valor = new ColumnHeader();
            Descrição_Transação = new ColumnHeader();
            Data_Transação = new ColumnHeader();
            Nome_Categoria = new ColumnHeader();
            Tipo_Categoria = new ColumnHeader();
            Nome = new ColumnHeader();
            label5 = new Label();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)homelogobee).BeginInit();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // homelabelnamebusiness
            // 
            homelabelnamebusiness.AutoSize = true;
            homelabelnamebusiness.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            homelabelnamebusiness.ForeColor = Color.Yellow;
            homelabelnamebusiness.Location = new Point(12, 95);
            homelabelnamebusiness.Name = "homelabelnamebusiness";
            homelabelnamebusiness.Size = new Size(132, 28);
            homelabelnamebusiness.TabIndex = 6;
            homelabelnamebusiness.Text = "PCbeeS";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.Location = new Point(19, 189);
            label1.Name = "label1";
            label1.Size = new Size(163, 17);
            label1.TabIndex = 7;
            label1.Text = "Tipo Transação:";
            // 
            // homelogobee
            // 
            homelogobee.Image = (Image)resources.GetObject("homelogobee.Image");
            homelogobee.Location = new Point(12, 17);
            homelogobee.Name = "homelogobee";
            homelogobee.Size = new Size(62, 75);
            homelogobee.SizeMode = PictureBoxSizeMode.Zoom;
            homelogobee.TabIndex = 9;
            homelogobee.TabStop = false;
            // 
            // homelogocalculator
            // 
            homelogocalculator.Image = (Image)resources.GetObject("homelogocalculator.Image");
            homelogocalculator.Location = new Point(80, 33);
            homelogocalculator.Name = "homelogocalculator";
            homelogocalculator.Size = new Size(61, 59);
            homelogocalculator.SizeMode = PictureBoxSizeMode.Zoom;
            homelogocalculator.TabIndex = 10;
            homelogocalculator.TabStop = false;
            // 
            // txt_tipo_transacao
            // 
            txt_tipo_transacao.Location = new Point(22, 211);
            txt_tipo_transacao.Name = "txt_tipo_transacao";
            txt_tipo_transacao.Size = new Size(250, 23);
            txt_tipo_transacao.TabIndex = 11;
            // 
            // btn_enviartransacao
            // 
            btn_enviartransacao.BackColor = Color.Black;
            btn_enviartransacao.FlatAppearance.BorderColor = Color.Yellow;
            btn_enviartransacao.FlatAppearance.BorderSize = 2;
            btn_enviartransacao.FlatAppearance.MouseDownBackColor = Color.FromArgb(33, 33, 33);
            btn_enviartransacao.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 33, 33);
            btn_enviartransacao.FlatStyle = FlatStyle.Flat;
            btn_enviartransacao.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_enviartransacao.ForeColor = Color.Yellow;
            btn_enviartransacao.Location = new Point(19, 743);
            btn_enviartransacao.Margin = new Padding(0);
            btn_enviartransacao.Name = "btn_enviartransacao";
            btn_enviartransacao.Size = new Size(89, 33);
            btn_enviartransacao.TabIndex = 13;
            btn_enviartransacao.Text = "Enviar";
            btn_enviartransacao.UseVisualStyleBackColor = false;
            btn_enviartransacao.Click += btn_enviartransacao_Click;
            // 
            // exitbtn_transacao
            // 
            exitbtn_transacao.FlatAppearance.BorderColor = Color.Black;
            exitbtn_transacao.FlatAppearance.BorderSize = 0;
            exitbtn_transacao.FlatAppearance.MouseDownBackColor = Color.Black;
            exitbtn_transacao.FlatAppearance.MouseOverBackColor = Color.Black;
            exitbtn_transacao.FlatStyle = FlatStyle.Flat;
            exitbtn_transacao.Image = (Image)resources.GetObject("exitbtn_transacao.Image");
            exitbtn_transacao.Location = new Point(525, 735);
            exitbtn_transacao.Name = "exitbtn_transacao";
            exitbtn_transacao.RightToLeft = RightToLeft.No;
            exitbtn_transacao.Size = new Size(45, 48);
            exitbtn_transacao.TabIndex = 14;
            exitbtn_transacao.UseVisualStyleBackColor = true;
            exitbtn_transacao.Click += exitbtn_transacao_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Yellow;
            label3.Location = new Point(166, 48);
            label3.Name = "label3";
            label3.Size = new Size(180, 28);
            label3.TabIndex = 15;
            label3.Text = "Transação";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Yellow;
            label10.Location = new Point(319, 189);
            label10.Name = "label10";
            label10.RightToLeft = RightToLeft.No;
            label10.Size = new Size(179, 17);
            label10.TabIndex = 26;
            label10.Text = "Valor Transação:";
            // 
            // txt_valor_transacao
            // 
            txt_valor_transacao.Location = new Point(323, 211);
            txt_valor_transacao.Name = "txt_valor_transacao";
            txt_valor_transacao.Size = new Size(250, 23);
            txt_valor_transacao.TabIndex = 27;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Yellow;
            label12.Location = new Point(12, 152);
            label12.Name = "label12";
            label12.RightToLeft = RightToLeft.No;
            label12.Size = new Size(180, 28);
            label12.TabIndex = 40;
            label12.Text = "Transação";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(18, 18, 18);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txt_nome_usuario);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txt_tipo_categoria);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txt_nome_categoria);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(txt_data_transacao);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txt_descricao_transacao);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(txt_valor_transacao);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(exitbtn_transacao);
            panel1.Controls.Add(btn_enviartransacao);
            panel1.Controls.Add(txt_tipo_transacao);
            panel1.Controls.Add(homelogocalculator);
            panel1.Controls.Add(homelogobee);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(homelabelnamebusiness);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(600, 800);
            panel1.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Yellow;
            label6.Location = new Point(12, 483);
            label6.Name = "label6";
            label6.RightToLeft = RightToLeft.No;
            label6.Size = new Size(141, 28);
            label6.TabIndex = 52;
            label6.Text = "Usuário";
            // 
            // txt_nome_usuario
            // 
            txt_nome_usuario.Location = new Point(22, 542);
            txt_nome_usuario.Name = "txt_nome_usuario";
            txt_nome_usuario.Size = new Size(250, 23);
            txt_nome_usuario.TabIndex = 51;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Yellow;
            label11.Location = new Point(19, 520);
            label11.Name = "label11";
            label11.Size = new Size(170, 17);
            label11.TabIndex = 50;
            label11.Text = "Nome Categoria:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Yellow;
            label7.Location = new Point(12, 353);
            label7.Name = "label7";
            label7.RightToLeft = RightToLeft.No;
            label7.Size = new Size(173, 28);
            label7.TabIndex = 49;
            label7.Text = "Categoria";
            // 
            // txt_tipo_categoria
            // 
            txt_tipo_categoria.Location = new Point(323, 412);
            txt_tipo_categoria.Name = "txt_tipo_categoria";
            txt_tipo_categoria.Size = new Size(250, 23);
            txt_tipo_categoria.TabIndex = 48;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Yellow;
            label8.Location = new Point(319, 390);
            label8.Name = "label8";
            label8.RightToLeft = RightToLeft.No;
            label8.Size = new Size(159, 17);
            label8.TabIndex = 47;
            label8.Text = "Tipo Categoria:";
            // 
            // txt_nome_categoria
            // 
            txt_nome_categoria.Location = new Point(22, 412);
            txt_nome_categoria.Name = "txt_nome_categoria";
            txt_nome_categoria.Size = new Size(250, 23);
            txt_nome_categoria.TabIndex = 46;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Yellow;
            label9.Location = new Point(19, 390);
            label9.Name = "label9";
            label9.Size = new Size(170, 17);
            label9.TabIndex = 45;
            label9.Text = "Nome Categoria:";
            // 
            // txt_data_transacao
            // 
            txt_data_transacao.Location = new Point(323, 276);
            txt_data_transacao.Name = "txt_data_transacao";
            txt_data_transacao.Size = new Size(250, 23);
            txt_data_transacao.TabIndex = 44;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Yellow;
            label2.Location = new Point(319, 254);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(170, 17);
            label2.TabIndex = 43;
            label2.Text = "Data Transação:";
            // 
            // txt_descricao_transacao
            // 
            txt_descricao_transacao.Location = new Point(22, 276);
            txt_descricao_transacao.Name = "txt_descricao_transacao";
            txt_descricao_transacao.Size = new Size(250, 23);
            txt_descricao_transacao.TabIndex = 42;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("BankGothic Md BT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Yellow;
            label4.Location = new Point(19, 254);
            label4.Name = "label4";
            label4.Size = new Size(223, 17);
            label4.TabIndex = 41;
            label4.Text = "Descrição Transação:";
            // 
            // lv_show_transacao
            // 
            lv_show_transacao.Columns.AddRange(new ColumnHeader[] { Nome, Tipo_Transação, Valor, Descrição_Transação, Data_Transação, Nome_Categoria, Tipo_Categoria });
            lv_show_transacao.Location = new Point(31, 95);
            lv_show_transacao.Name = "lv_show_transacao";
            lv_show_transacao.Size = new Size(541, 688);
            lv_show_transacao.TabIndex = 17;
            lv_show_transacao.UseCompatibleStateImageBehavior = false;
            lv_show_transacao.View = View.Details;
            lv_show_transacao.SelectedIndexChanged += lv_show_transacao_SelectedIndexChanged;
            // 
            // Tipo_Transação
            // 
            Tipo_Transação.Text = "Tipo_Transação";
            Tipo_Transação.Width = 120;
            // 
            // Valor
            // 
            Valor.Text = "Valor";
            Valor.Width = 120;
            // 
            // Descrição_Transação
            // 
            Descrição_Transação.Text = "Descrição_Transação";
            Descrição_Transação.Width = 120;
            // 
            // Data_Transação
            // 
            Data_Transação.Text = "Data_Transação";
            Data_Transação.Width = 120;
            // 
            // Nome_Categoria
            // 
            Nome_Categoria.Text = "Nome_Categoria";
            Nome_Categoria.Width = 120;
            // 
            // Tipo_Categoria
            // 
            Tipo_Categoria.Text = "Tipo_Categoria";
            Tipo_Categoria.Width = 120;
            // 
            // Nome
            // 
            Nome.Text = "Nome";
            Nome.Width = 120;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("BankGothic Md BT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(31, 48);
            label5.Name = "label5";
            label5.Size = new Size(212, 28);
            label5.TabIndex = 16;
            label5.Text = "Informações";
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightGray;
            panel2.Controls.Add(lv_show_transacao);
            panel2.Controls.Add(label5);
            panel2.Location = new Point(600, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(600, 800);
            panel2.TabIndex = 2;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 800);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form4";
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)homelogobee).EndInit();
            ((System.ComponentModel.ISupportInitialize)homelogocalculator).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label homelabelnamebusiness;
        private Label label1;
        private PictureBox homelogobee;
        private PictureBox homelogocalculator;
        private TextBox txt_tipo_transacao;
        private Button btn_enviartransacao;
        private Button exitbtn_transacao;
        private Label label3;
        private Label label10;
        private TextBox txt_valor_transacao;
        private Label label12;
        private Panel panel1;
        private TextBox txt_data_transacao;
        private Label label2;
        private TextBox txt_descricao_transacao;
        private Label label4;
        private Label label7;
        private TextBox txt_tipo_categoria;
        private Label label8;
        private TextBox txt_nome_categoria;
        private Label label9;
        private ListView lv_show_transacao;
        private Label label5;
        private Panel panel2;
        private ColumnHeader Tipo_Transação;
        private ColumnHeader Valor;
        private ColumnHeader Descrição_Transação;
        private ColumnHeader Data_Transação;
        private ColumnHeader Nome_Categoria;
        private ColumnHeader Tipo_Categoria;
        private ColumnHeader Nome;
        private Label label6;
        private TextBox txt_nome_usuario;
        private Label label11;
    }
}